# Choose Plan V2

App pessoal de finanças. V2 inclui lançamentos persistentes no aparelho, receitas/despesas, edição, exclusão, meses, gráficos por categoria, comparação mensal, análise automática e exportação/importação de backup JSON.

O backup JSON pode ser guardado no Google Drive manualmente. A integração direta com Google Drive será adicionada em uma etapa posterior.

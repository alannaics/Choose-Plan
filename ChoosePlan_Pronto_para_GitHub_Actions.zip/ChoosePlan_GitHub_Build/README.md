# Choose Plan — projeto Android

Projeto Android inicial do Choose Plan.

## O que já está incluído
- Aplicativo Android com Activity nativa
- WebView local, sem servidor externo
- Protótipo visual branco + rosa
- Início, Gráficos, Relatórios e Perfil
- Cadastro local de receitas/despesas
- Análises demonstrativas do mês
- Dados do protótipo armazenados localmente pelo WebView

## Como gerar o APK
Abra esta pasta no Android Studio e aguarde a sincronização do Gradle.
Depois use:
Build > Build APK(s)

O APK de debug será gerado em:
app/build/outputs/apk/debug/app-debug.apk

## Observação
A integração real com Google Drive ainda não está implementada. Ela deve ser adicionada depois, com autenticação Google e uma estratégia de backup/restauração.

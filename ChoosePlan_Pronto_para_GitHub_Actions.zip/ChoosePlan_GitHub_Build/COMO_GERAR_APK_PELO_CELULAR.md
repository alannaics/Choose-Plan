# Como gerar o APK usando apenas o celular

1. Crie uma conta no GitHub ou entre na sua conta.
2. Crie um repositório novo chamado `ChoosePlan`.
3. Pelo navegador do celular, envie TODOS os arquivos e pastas desta pasta para o repositório.
   - Não envie apenas o ZIP.
   - A pasta `.github/workflows` precisa existir no repositório.
4. Depois de enviar os arquivos, abra a aba **Actions** do repositório.
5. Selecione **Build Choose Plan APK**.
6. Toque em **Run workflow**.
7. Aguarde a compilação terminar.
8. Abra a execução concluída.
9. Na seção **Artifacts**, baixe `ChoosePlan-APK`.
10. Dentro do ZIP baixado estará o arquivo `app-debug.apk`.
11. Toque no APK para instalar o Choose Plan.

O workflow usa Java 17 e Gradle 8.7 e compila uma versão debug do aplicativo.
Não há chaves de assinatura particulares incluídas neste projeto.

## Segurança

Não coloque senhas, tokens, dados financeiros ou arquivos pessoais no repositório.
O projeto atual não contém credenciais Google nem dados financeiros reais.

## Próxima etapa

Depois que o APK abrir no celular, podemos continuar o desenvolvimento do aplicativo:
- banco de dados financeiro real;
- análises mensais calculadas automaticamente;
- contas e cartões;
- parcelamentos e recorrências;
- backup no Google Drive;
- ícone e tela de abertura;
- versão assinada para distribuição.
